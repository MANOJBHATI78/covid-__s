# Shot Of Hope

- Shot of Hope is a basic CRUD application that allows users to book an appointment online for Covid vaccination.
- It allows admins to view all appointments received for a particular hospital, and also add more hospitals & slots.
